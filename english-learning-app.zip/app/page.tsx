"use client"

import  from "../static/js/app"

export default function SyntheticV0PageForDeployment() {
  return < />
}